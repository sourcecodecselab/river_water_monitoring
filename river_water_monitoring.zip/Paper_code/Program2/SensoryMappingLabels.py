
import numpy as np
import pandas as pd
from collections import defaultdict
import mpu

Sen = pd.read_csv("Sensor_final_without_label.csv")
Sen = pd.concat([Sen, (pd.Series()).rename('Score')],axis = 1)
lab  = pd.read_csv("LabWithLabels.csv")
lab.pop("Unnamed: 0");
lab.pop("CLASS");

# Grouping accdng to river(Lab)

rivL = defaultdict()
a = lab.groupby("River")

for x  in lab['River'].unique():
    rivL[x] = a.get_group(x)
    
#Setting Thresholds for time and allowed distances

TimeT = 30
GPST = 100

ir = list(lab.columns).index('River')
iLon = list(lab.columns).index('Longitude')
iLa= list(lab.columns).index('Latitude')
iT = list(lab.columns).index('Time')
iLoc = list(lab.columns).index('Location')
iDa = list(lab.columns).index('Date')
iLab = list(lab.columns).index('Label')


q = 0
o = 0
rem= ['NROR','FRKA','GZBD', 'JGPR', 'KRCF','NGVR','NROR','PYRJ','ULSR']
print("DS")
for i in range(0, len(Sen)):
    k=1
    Sen["Score"][i] = np.nan
   # print(i)
    if(i%10000 == 1):
        print(i)
    if(Sen['water_body_container'][i] == 'BGLR'):
        continue
    if(Sen['water_body_location'][i] in rem):
        continue
    if(Sen['water_body_location'][i] == 'KNPR'):
        p = 'KANP'
    elif(Sen['water_body_location'][i] == 'KRSN'):
        p = 'KRNS'
    else:
        p = Sen['water_body_location'][i]
    u  = rivL[Sen['water_body_container'][i]].groupby('Location').get_group(p)
    for j in range(0,len(u)):
        if(u.iloc[j, iDa] == Sen['Date'][i]):
            if((u.iloc[j,iT] - Sen['Time'][i]) < 60):
                lat1 = Sen['lat'][i]
                lon1 = Sen['lon'][i]
                lat2 = u.iloc[j , iLa]
                lon2 = u.iloc[j, iLon]
                if(mpu.haversine_distance((lat1, lon1), (lat2, lon2))<100):
                    if(k==1):
                        Sen["Score"][i] = u.iloc[j,iLab]
                        k=k+1
                    else: 
                        Sen["Score"][i] = (Sen["Score"][i]*(k-1) + u.iloc[j,iLab])/(k)
                        k=k+1
print("Sensor values that got a similar point in Lab Data", (~(Sen["Score"].isna())).sum())
Sen = Sen.dropna()
Sen = Sen.sample(frac=1)
a = (np.round(Sen["Score"])-2)
Sen = pd.concat([Sen,pd.Series(a).rename("ScoreR-1")],axis=1)
