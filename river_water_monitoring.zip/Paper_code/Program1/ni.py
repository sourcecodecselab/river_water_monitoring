# -*- coding: utf-8 -*-
"""
Created on Sat Oct  5 20:39:38 2019

@author: swati
"""
import pandas as pd
import numpy as np
l=0
X=[]
Y=[]
ni=[]
df=pd.read_csv("wqi_without_labels.csv")

X=df["NO3_ppm"].values

xni=np.array([0.0,2.0,3.0,3.5,4.0,6.0,10.0,17.0,27.0,37.0,50.0,54.0,71.0,80.0,90.0,100.0])
yni=np.array([97.0,95.0,90.0,80.0,70.0,60.0,51.0,40.0,30.0,20.0,10.0,8.0,4.0,4.5,3.0,2.5])
#cnt=10  
def calcniwqi():

  
  cnt=16
  global l
  
  if (X[l] < 0) :
      Y.append(99)
      l=l+1
      return(Y)
  elif (X[l]>100):
      Y.append(1)
      
      l=l+1
      return(Y)
  else:
    Y.append(round((dattowqi(X[l],cnt,xni,yni))))
    print("X[l]=",X[l])
    l=l+1
    return(Y) 
   
def dattowqi(dat,len1,xarray,yarray):
    #xarray=np.array([0.0,10.0,20.0,30.0,40.0,60.0,70.0,150.0,450.0,500.0])
    #yarray=np.array([79.0,82.0,84.0,84.5,86.0,87.0,86.0,79.0,40.0,31.0])
       
    found=False
    i=0
    while i < len1 and not (found):
          if (xarray[i] <= dat and dat <= xarray[i+1] and not(found)):
            found=True
          i=i+1 
    print("i=",i)  
    if found:
      i=i-1
      print(i)
    return(xtoy(dat,xarray[i],xarray[i+1],yarray[i],yarray[i+1]))
       
    return 100     

def xtoy(x,x0,x1,y0,y1):
    #xarray=np.array([0.0,10.0,20.0,30.0,40.0,60.0,70.0,150.0,450.0,500.0])
    #yarray=np.array([79.0,82.0,84.0,84.5,86.0,87.0,86.0,79.0,40.0,31.0])
    m = (y1-y0) / (x1-x0)
    z=y0+m*(x-x0)
    print("m=",z)
    return (z)
    
  
  
'''for i in range(561):
    ni=calcniwqi()
    print("ni=",ni)
    
final=pd.DataFrame()    
final = pd.concat([df, pd.Series(ni)], axis=1)
final.to_csv("/home/swati/Downloads/Python programs/wqi.csv",index=False)
final=pd.read_csv("wqi.csv",index_col=0)
final.rename(columns={"0": "wqi_NO3"}, inplace=True)
final.to_csv("wqi.csv",index=False)'''
