# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 16:29:37 2019

@author: swati
"""


import numpy as np
import pandas as pd
xfc=np.array([0.0,2.0,3.0,4.0,5.0])
yfc=np.array([99.0,44.0,22.0,10.0,4.0])
df=pd.read_csv("wqi_without_labels.csv")


X=df["FC_cfu_100ml"].values

Y=[]
i=0
fc=[]
cnt=5
def calcfcwqi():

  
  
  global i
  #inval=float(input("Enter your value of x of fc :="))
  #print(inval)
  if X[i] < 1:
     #outval="out of range"
     Y.append(100)
     i=i+1
     return(Y)
  elif (X[i] > 100000):
      Y.append(2)
      i=i+1
      return(Y)
      
  else: 
       Y.append(round((dattowqi((np.log(X[i])/np.log(10)),cnt,xfc,yfc))))
       i=i+1
       return(Y)
   
def dattowqi(dat,len1,xarray,yarray):
    
    print("dat=",dat)   
    found=False
    i=0
    while (i < len1-1) and (not (found)):
          if ((xarray[i] <= dat) and (dat <= xarray[i+1]) and (not (found))):
            found=True
          i=i+1 
    print("i1=",i,"=",found)  
    if found:
      i=i-1
      print("i2",i)
    return(xtoy(dat,xarray[i],xarray[i+1],yarray[i],yarray[i+1]))
       
    return 100     

def xtoy(x,x0,x1,y0,y1):
    
    m = (y1-y0) / (x1-x0)
    z=y0+m*(x-x0)
    print("m=",z)
    return (z)
    
'''for i in range(561):
    fc=calcfcwqi()
    print("fc=",fc)
    
f1=pd.DataFrame()   
f1 = pd.concat([df, pd.Series(fc)], axis=1)
f1.to_csv("/home/swati/Downloads/Python programs/wqi.csv",index=False)
f1=pd.read_csv("wqi.csv")
f1.rename(columns={"0": "wqi_FC"}, inplace=True)
f1.to_csv("wqi.csv",index=False)'''
 
