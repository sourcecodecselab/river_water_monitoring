# -*- coding: utf-8 -*-
"""
Created on Sat Oct  5 20:22:29 2019

@author: swati
"""

import pandas as pd
import numpy as np

j=0
X=[]
Y=[]
turby=[]
df=pd.read_csv("wqi_without_labels.csv")
X=df["Turbidity_NTU"].values
xturb=np.array([0.0,3.0,8.0,13.0,15.0,20.0,30.0,40.0,50.0,60.0,70.0,80.0,90.0,100.0])
yturb=np.array([99.0,90.0,80.0,70.0,67.0,61.0,53.0,45.0,39.0,33.0,29.0,25.0,22.0,17.0])
def calcturbwqi():

  
  cnt=15
  
        
  global j
  #n=len(X)
    
  #for index, item in enumerate(Y):
   #   Y[index] = float(item)
  
  #inval=X[i]#float(input("Enter your value of x of turbidity:="))
  #print(inval)
  #inval=3.5
  
  if (float(X[j]) < 0) :
     Y.append(0)
     j=j+1
     return(Y)
  elif(float(X[j]) > 100):
      Y.append(5)    
      j=j+1
      return(Y)
     
  else:
      Y.append(round((dattowqi(float(X[j]),cnt,xturb,yturb))))
      j=j+1
      return(Y)
  
   
def dattowqi(dat,len1,xarray,yarray):
    
    
    found=False
    i=0
    
    while i < len1-1 and not (found):
          if (xarray[i] <= dat and dat <= xarray[i+1] and not(found)):
             found=True
          i=i+1 
    
    if found:
       i=i-1
       
    return(xtoy(dat,xarray[i],xarray[i+1],yarray[i],yarray[i+1]))
       
    return 100     

def xtoy(x,x0,x1,y0,y1):
    #xarray=np.array([0.0,10.0,20.0,30.0,40.0,60.0,70.0,150.0,450.0,500.0])
    #yarray=np.array([79.0,82.0,84.0,84.5,86.0,87.0,86.0,79.0,40.0,31.0])
    m = (y1-y0) / (x1-x0)
    z=y0+m*(x-x0)
    print("z=",z)
    return (z)
    
#b=calctpwqi()
#n=len(X)
'''for i in range(561):
    turby=calcturbwqi()
    print("turby=",turby)

final1=pd.DataFrame()
final1 = pd.concat([df, pd.Series(turby)], axis=1)
final1.to_csv("/home/swati/Downloads/Python programs/wqi.csv",index=False)
final1=pd.read_csv("wqi.csv")
final1.rename(columns={"0": "wqi_turbidity"}, inplace=True)
final1.to_csv("wqi.csv",index=False)'''

  
