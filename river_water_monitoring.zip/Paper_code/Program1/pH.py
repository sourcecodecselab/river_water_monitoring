# -*- coding: utf-8 -*-
"""
Created on Fri Oct  4 15:11:11 2019

@author: swati
"""
import pandas as pd
import numpy as np
m=0
X=[]
Y=[]
pH_y=[]
df=pd.read_csv("wqi_without_labels.csv")
X=df["pH"].values
xpH=np.array([2.0,3.0,3.5,4.0, 4.1, 4.5, 4.8, 5.1, 6.2, 6.8, 7.0, 7.1, 7.2, 7.4, 7.6, 7.8, 8.0, 8.9, 9.7,10.0,10.3,10.7,10.8,11.0,11.5,12.0])
ypH=np.array([2.0,4.0,6.0,9.0,10.0,15.0,20.0,30.0,60.0,83.0,88.0,90.0,92.0,93.0,92.0,90.0,84.0,52.0,26.0,20.0,15.0,11.0,10.0, 8.0, 5.0, 3.0])
#cnt=10  
def calcpHwqi():

  
  cnt=26
  global m
  #inval=float(input("Enter your value of x of pH :="))
  #print(inval)
  
  if ((X[m] < 2) or (12 < X[m])):
     Y.append(0)
     print("X[m]=",X[m])
     m=m+1
     return(Y)
  
  else:
    Y.append(round((dattowqi(X[m],cnt,xpH,ypH))))
    print("X[m]=",X[m])
    m=m+1
    return(Y)
     
def dattowqi(dat,len1,xarray,yarray):
    #xarray=np.array([0.0,10.0,20.0,30.0,40.0,60.0,70.0,150.0,450.0,500.0])
    #yarray=np.array([79.0,82.0,84.0,84.5,86.0,87.0,86.0,79.0,40.0,31.0])
       
    found=False
    i=0
    while i < len1 and not (found):
          if (xarray[i] <= dat and dat <= xarray[i+1] and not(found)):
            found=True
          i=i+1 
      
    if found:
      i=i-1
      
    return(xtoy(dat,xarray[i],xarray[i+1],yarray[i],yarray[i+1]))
       
    return 100     

def xtoy(x,x0,x1,y0,y1):
    #xarray=np.array([0.0,10.0,20.0,30.0,40.0,60.0,70.0,150.0,450.0,500.0])
    #yarray=np.array([79.0,82.0,84.0,84.5,86.0,87.0,86.0,79.0,40.0,31.0])
    m1 = (y1-y0) / (x1-x0)
    z=y0+m1*(x-x0)
    print("m1=",z)
    return (z)
    
'''for i in range(561):
    pH=calcpHwqi()
    print("pH=",pH)


final1=pd.DataFrame    
final1 = pd.concat([df, pd.Series(pH)], axis=1)
final1.to_csv("/home/swati/Downloads/Program1/wqi.csv",index=False)
d1=pd.read_csv("wqi.csv")
d1.rename(columns={"0": "pH"}, inplace=True)
d1.to_csv("wqi.csv",index=False)
 '''
    
        
