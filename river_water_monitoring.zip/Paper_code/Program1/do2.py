# -*- coding: utf-8 -*-
"""
Created on Sat Oct  5 20:07:56 2019

@author: swati
"""


import numpy as np
import pandas as pd
k=0
Z=[]
X=[]
Y=[]
s=[]
n=[]



df=pd.read_csv("wqi_without_labels.csv")
X=df["DO_per_sat"].values
xdo2=np.array([0.0,16.0,20.0,32.0,34.0,62.0,67.0,70.0,74.0,80.0,84.0,90.0,94.0,98.0,102.0,106.0,137.0,140.0])
ydo2=np.array([2.0,10.0,12.0,20.0,22.0,60.0,70.0,75.0,80.0,87.0,90.0,95.0,98.0,99.0,99.0,98.0,80.0,78.0])
#cnt=10  
def calcdo2wqi():

  global k
  
  #print(xdo2)
  #print(ydo2)
  cnt=18
  #inval=float(input("Enter your value of x of do2 :="))
  #print(inval)
  if (float (X[k]) < 0):
      k=k+1
      #print("outval=out of range")  
      Y.append(0)
  elif (float (X[k]) > 140):
      #Z= float (X[k]/7.7)*100
      #print("Z=",Z)
      k=k+1
      Y.append(50)
      return(Y)
     
  else:
      Y.append(round((dattowqi(X[k],cnt,xdo2,ydo2))))
      #print("Z=",Z)
      k=k+1
      return(Y)
  
   
def dattowqi(dat,len1,xarray,yarray):
    #xarray=np.array([0.0,10.0,20.0,30.0,40.0,60.0,70.0,150.0,450.0,500.0])
    #yarray=np.array([79.0,82.0,84.0,84.5,86.0,87.0,86.0,79.0,40.0,31.0])
       
    found=False
    i=0
    while i < len1 and not (found):
          if (xarray[i] <= dat and dat <= xarray[i+1] and not(found)):
            found=True
          i=i+1 
    print("i=",i)  
    if found:
      i=i-1
      print(i)
    return(xtoy(dat,xarray[i],xarray[i+1],yarray[i],yarray[i+1]))
       
    return 100     

def xtoy(x,x0,x1,y0,y1):
    #xarray=np.array([0.0,10.0,20.0,30.0,40.0,60.0,70.0,150.0,450.0,500.0])
    #yarray=np.array([79.0,82.0,84.0,84.5,86.0,87.0,86.0,79.0,40.0,31.0])
    m = (y1-y0) / (x1-x0)
    z=y0+m*(x-x0)
    print("m=",z)
    return (z)
    
    
'''for i in range(561):    
  do2y=calcdo2wqi()
  print("do2=",do2y)
  
final=pd.DataFrame()
df=pd.read_csv("wqi.csv")
final=pd.concat([df,pd.Series(do2y)],axis=1)
final.rename(columns={"0":"wqi_DO"},inplace=True)
final=final.loc[0:561,:]
final.to_csv("wqi.csv",index=False)
'''
