import pandas as pd
import turb
import ni
import pH
import do2
import FC_1
import bod_1

overall=[]
class1=[]


for i in range(561): 
    turb1=turb.calcturbwqi()
    turb1=turb1[i]*0.08/0.73
    ni1=ni.calcniwqi()
    ni1=ni1[i]*0.10/0.73 
    pH1=pH.calcpHwqi()
    pH1=pH1[i]*0.11/0.73    
    do=do2.calcdo2wqi()
    do=do[i]*0.17/0.73   
    fc=FC_1.calcfcwqi()
    fc=fc[i]*0.16/0.73   
    bod=bod_1.calcbodwqi()
    bod=bod[i]*0.11/0.73   
    overallwqi=turb1+ni1+pH1+do+fc+bod
    
    overall.append(round(turb1+ni1+pH1+do+fc+bod))
    
    if (overallwqi>=80 and overallwqi<100):
       class1.append("EXCELLENT")
    elif (overallwqi>=70 and overallwqi<80):
       class1.append("VERY GOOD")
    elif (overallwqi>=60 and overallwqi<70):
       class1.append("GOOD")
    elif overallwqi>=50 and overallwqi<60:
       class1.append("MEDIUM")
    elif overallwqi>=30 and overallwqi<50:
       class1.append("BAD")   
    else:    
       class1.append("VERY_BAD")
       
finaldf = pd.DataFrame()       
data=pd.read_csv("wqi_without_labels.csv",index_col=0)
finaldf = pd.concat([data, pd.Series(overall)], axis=1)
finaldf = pd.concat([finaldf, pd.Series(class1)], axis=1)
finaldf.rename(columns={"0": "OVERALL WQI"}, inplace=True)
finaldf.rename(columns={"0.1": "CLASS"}, inplace=True)
finaldf=finaldf.loc[0:561,:]
finaldf.to_csv("wqi_with_labels.csv",index=False)




