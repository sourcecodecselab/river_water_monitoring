# -*- coding: utf-8 -*-
"""
Created on Wed Oct 16 12:45:29 2019

@author: swati
"""
import pandas as pd
import numpy as np
i=0
X=[]
Y=[]
bod=[]
df=pd.read_csv("wqi_without_labels.csv")
X=df["BOD_ppm"].values

xbod=np.array([0.0,0.5,1.0,1.5,2.5,4.0,6.5,8.5,11.0,15.0,17.5,20.0,21.5,25.0,27.0,30.0])
ybod=np.array([100.0,98.0,95.0,90.0,70.0,61.0,48.0,40.0,30.0,20.0,15.0,12.0,10.0,7.0,6.0,5.0])
#cnt=10  
def calcbodwqi():

  global i
  cnt=26
  if float(X[i]) < 0:
     Y.append(0)
     i=i+1
     return(Y)
  elif (30 < float(X[i])) :
     Y.append(5)
     i=i+1
     return(Y) 
  else:
    Y.append(round((dattowqi(float(X[i]),cnt,xbod,ybod))))
    i=i+1
    return(Y)
    
def dattowqi(dat,len1,xarray,yarray):
       
    found=False
    i=0
    while i < len1 and not (found):
          if (xarray[i] <= dat and dat <= xarray[i+1] and not(found)):
            found=True
          i=i+1 
    print("i=",i)  
    if found:
      i=i-1
      print(i)
    return(xtoy(dat,xarray[i],xarray[i+1],yarray[i],yarray[i+1]))
       
    return 100     

def xtoy(x,x0,x1,y0,y1):
    m = (y1-y0) / (x1-x0)
    z=y0+m*(x-x0)
    print("m=",z)
    return (z)
    

