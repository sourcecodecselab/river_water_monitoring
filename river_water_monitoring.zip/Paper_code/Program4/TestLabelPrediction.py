import numpy as np
import pandas as pd
from torch.nn import Parameter
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import torch
import torch.nn as nn
import torch.nn.functional as F


def sigmoid(x, derivative=False):
    x_safe = x 
    f = 1 / (1 + np.exp(-x_safe))
    
    if derivative:
        return f * (1 - f)
    else: 
        return f

data = pd.read_csv("Sensor_final_with_labels.csv")

model1 = StandardScaler()
SenT= model1.fit_transform(data.iloc[:,4:13])
Sc =(data.iloc[:,-1])
X_train, X_test, y_train, y_test = train_test_split(np.array(SenT),np.array(Sc), shuffle=True, test_size=0.20, random_state=42)
X_train = torch.tensor(X_train)
X_train = X_train.to(torch.float32)
X_test = torch.tensor(X_test)
X_test = X_test.to(torch.float32)
y_train = torch.tensor(y_train)
X_train = X_train[:,:-2]
X_test = X_test[:,:-2]

LabelChk = pd.read_csv("TestCheck.csv")
X_labelcheck = LabelChk.iloc[:,:-1]
X_labelcheck = model1.fit_transform(X_labelcheck)

print(X_train.shape)
print(X_test.shape)

from enum import IntEnum
class Dim(IntEnum):
    batch = 0
    seq = 1
    feature = 2
    
class LSTMCotinueExample(nn.Module):
    def __init__(self, input_sz: int, hidden_sz: int):
        super().__init__()  
        self.input_size = input_sz
        self.hidden_size = hidden_sz
        # input gate
        self.W_ii = Parameter(torch.Tensor(input_sz, hidden_sz))
        self.W_hi = Parameter(torch.Tensor(hidden_sz, hidden_sz))
        self.b_i = Parameter(torch.Tensor(hidden_sz))
        # forget gate
        self.W_if = Parameter(torch.Tensor(input_sz, hidden_sz))
        self.W_hf = Parameter(torch.Tensor(hidden_sz, hidden_sz))
        self.b_f = Parameter(torch.Tensor(hidden_sz))
        # ???
        self.W_ig = Parameter(torch.Tensor(input_sz, hidden_sz))
        self.W_hg = Parameter(torch.Tensor(hidden_sz, hidden_sz))
        self.b_g = Parameter(torch.Tensor(hidden_sz))
        # output gate
        self.W_io = Parameter(torch.Tensor(input_sz, hidden_sz))
        self.W_ho = Parameter(torch.Tensor(hidden_sz, hidden_sz))
        self.b_o = Parameter(torch.Tensor(hidden_sz))
         
        self.init_weights()
     
    def init_weights(self):
        for p in self.parameters():
            if p.data.ndimension() >= 2:
                nn.init.xavier_uniform_(p.data)
            else:
                nn.init.zeros_(p.data)
         
    def forward(self, x: torch.Tensor, 
                init_states = None):
        """Assumes x is of shape (batch, sequence, feature)"""
        bs, seq, feature = x.size()
        hidden_seq = torch.tensor([])
        if init_states is None:
            h_t, c_t = torch.zeros(self.hidden_size).to(x.device), torch.zeros(self.hidden_size).to(x.device)
        else:
            h_t, c_t = init_states
        for t in range(0, seq): # iterate over the time steps
            x_t = x[:, t, :]
            i_t = torch.sigmoid(x_t @ self.W_ii + h_t @ self.W_hi + self.b_i)
            f_t = torch.sigmoid(x_t @ self.W_if + h_t @ self.W_hf + self.b_f)
            g_t = torch.tanh(x_t @ self.W_ig + h_t @ self.W_hg + self.b_g)
            o_t = torch.sigmoid(x_t @ self.W_io + h_t @ self.W_ho + self.b_o)
            c_t = f_t * c_t + i_t * g_t
            h_t = o_t * torch.tanh(c_t) 
            hidden_seq = torch.cat([hidden_seq,h_t], axis=0)
        return hidden_seq, (h_t, c_t)


class Model(nn.Module):
    def __init__(self):
        super().__init__()
        self.lstm3 = LSTMCotinueExample(7,25)
        self.f = nn.Flatten()
        self.fc1 = nn.Linear(3*50, 50)
        self.fc5 = nn.Linear(50, 25)
        self.fc6 = nn.Linear(25, 5)
    def forward(self, x):
        x = (self.lstm3(x.view([1,-1,7])))
        x = x[0]
        x = self.fc6(x)
        x = F.softmax(x, dim=1)
        return x

torch.manual_seed(1)
model = Model()
optimi = torch.optim.Adam( model.parameters(), lr=0.01)
Loss= nn.CrossEntropyLoss()
epochs = 100
batch_size=2000
itr = (X_train.shape[0]//batch_size)+1

for ep in range(0,20):
    for _ in range(0,10):
        for i in range(0,itr):
            if(i == itr-1):
                X_b = X_train[batch_size*i:, :]
                y_b = y_train[batch_size*i:]
            else:
                X_b = X_train[(batch_size*i):(batch_size*(i+1)), :]
                y_b = y_train[(batch_size*i):(batch_size*(i+1))]
            if(X_b.shape[0] == 0):
                continue   
            optimi.zero_grad()
            y_pred = model.forward(X_b)  
            loss = Loss(y_pred.reshape([-1,5]),y_b.view([-1,]).long())
            loss.backward()
            optimi.step()
    print("Accuracy after ",10*(ep+1),"epochs on training dataset is ",((torch.max(model(torch.tensor(X_train).float()).view([-1,5]),1)[1] == torch.tensor(y_train)).sum()).numpy()/y_train.shape[0])
    print("Accuracy after ",10*(ep+1),"epochs on testing dataset is ",((torch.max(model(torch.tensor(X_test).float()).view([-1,5]),1)[1] == torch.tensor(y_test)).sum()).numpy()/y_test.shape[0])

X_withLabels= pd.concat([LabelChk,pd.Series(torch.max(model(torch.tensor(X_labelcheck).float()).view([-1,5]),1)[1]).rename("Predicted Labels")],axis=1)
X_withLabels.to_csv("TestCheckWithPredictedLabels.csv")

